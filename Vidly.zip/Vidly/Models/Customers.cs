﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Vidly.Models
{
    public class Customers
    {
        public int ID { get; set; }

        [Required]
        [StringLength(255)]
        public string  Name { get; set; }
       
        public bool IsSubscriberToNewsLetter { get; set; }

        [Display(Name = "Membership Type")]
        public int MembershipTypeID { get; set; }

        [ForeignKey("MembershipTypeID")]
        public MembershipType MembershipType { get; set; }

        [Display(Name="Date Of Birth")]
        [Min18YearsIfAMember]
        public DateTime? BirthDate { get; set; }
        
    }
}