﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Vidly.Models
{
    public class Min18YearsIfAMember : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            
            var customer = (Customers)validationContext.ObjectInstance;

            if (customer.MembershipTypeID == MembershipType.Unknown || customer.MembershipTypeID == MembershipType.PayAsGo)
                return ValidationResult.Success;
            if(customer.BirthDate == null)
                return new ValidationResult("Birthdate is required");

            var age = DateTime.Now.Year - customer.BirthDate.Value.Year;

            return (age > 0) ? ValidationResult.Success : new ValidationResult("Customer age is below 18");
        }
    }
}