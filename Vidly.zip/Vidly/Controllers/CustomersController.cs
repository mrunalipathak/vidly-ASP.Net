﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vidly.Models;
using System.Data.Entity;
using Vidly.ViewModel;

namespace Vidly.Controllers
{
    public class CustomersController : Controller
    {
        private ApplicationDbContext _context;

        public CustomersController()
        {
            _context = new ApplicationDbContext();
        }
        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }
        // GET: Customer
        public ActionResult Index()
        {
            var customers = _context.Customer.Include(c=>c.MembershipType).ToList();
           
            return View(customers);
        }
        public ActionResult Details(int id)
        {
            var customerDetails = _context.Customer.Include(c => c.MembershipTypeID).SingleOrDefault(c => c.ID == id);

            if (customerDetails == null)
                return HttpNotFound();

            return View(customerDetails);
        }

        public ActionResult New()
        {
            var memberShipType = _context.MembershipType.ToList();
            var viewModel = new CustomerFormViewModel()
            {
                MembershipType = memberShipType
            };
            return View("CustomerForm", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Save(Customers customer)
        {
            if(!ModelState.IsValid)
            {
                var viewModel = new CustomerFormViewModel(customer)
                {
                    MembershipType = _context.MembershipType.ToList()
                };
                return View("CustomerForm", viewModel);
            }
            if(customer.ID == 0)
                 _context.Customer.Add(customer);
            else
            {
                var updateCustomer = _context.Customer.Single(c => c.ID == customer.ID);

                updateCustomer.Name = customer.Name;
                updateCustomer.BirthDate = customer.BirthDate;
                updateCustomer.MembershipTypeID = customer.MembershipTypeID;
                updateCustomer.IsSubscriberToNewsLetter = customer.IsSubscriberToNewsLetter;
            }
            _context.SaveChanges();

            return RedirectToAction("Index", "Customers");
        }

        public ActionResult Edit(int Id)
        {
            var customer = _context.Customer.SingleOrDefault(c => c.ID == Id);

            if (customer == null)
                return HttpNotFound();

            var viewModel = new CustomerFormViewModel(customer)
            {
                MembershipType = _context.MembershipType.ToList()
            };

            return View("CustomerForm", viewModel);
        }
        //private IEnumerable<Customers> GetCustomers()
        //{
        //    return new List<Customers>
        //    {
        //         new Customers{ID = 1, Name = "Jhon"},
        //        new Customers{ID = 2, Name = "Smith"}
        //    };
        //}

    }
}