﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data.Entity;
using Vidly.Dtos;
using Vidly.Models;
using AutoMapper;

namespace Vidly.Controllers.Api
{
    [Authorize]
    public class CustomersController : ApiController
    {
        private ApplicationDbContext _context;

        public CustomersController()
        {
            _context = new ApplicationDbContext();
        }
        
        //GET /api/customers 
        public IHttpActionResult GetCustomers(string query = null)
        {
            var customersQuery = _context.Customer
                                 .Include(c => c.MembershipType);
            if(!string.IsNullOrWhiteSpace(query))
                customersQuery = customersQuery.Where(c=>c.Name.Contains(query));

            var customerDtos = customersQuery.ToList().Select(Mapper.Map<Customers, CustomerDtos>).ToList();
           
            return Ok(customerDtos);
        }

        //GET /api/customers/1
        public IHttpActionResult GetCustomers(int id)
        {
            var customers = _context.Customer.SingleOrDefault(m => m.ID == id);

            if (customers == null)
                return NotFound();

            return Ok(Mapper.Map<Customers, CustomerDtos>(customers));
        }

        //POST /api/customers
        [HttpPost]
        public IHttpActionResult CreateCustomers(CustomerDtos customerDtos)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var customer = Mapper.Map<CustomerDtos, Customers>(customerDtos);
             _context.Customer.Add(customer);
             _context.SaveChanges();

             customerDtos.ID = customer.ID;

             return Created(new Uri(Request.RequestUri + "/" + customer.ID), customerDtos);
        }

        //PUT /api/customers/1
        [HttpPut]
        public void UpdateCustomer(int id, CustomerDtos customerDtos)
        {
            if (!ModelState.IsValid)
                throw new HttpResponseException(HttpStatusCode.BadRequest);

            var customerUpDb = _context.Customer.SingleOrDefault(m => m.ID == id);

            if (customerUpDb == null)
                throw new HttpResponseException(HttpStatusCode.NotFound);

            Mapper.Map(customerDtos, customerUpDb);
            
            _context.SaveChanges();
        }

        //DELETE api/customer/id
        [HttpDelete]
        public void DeleteCustomer(int id)
        {
            var customerUpDb = _context.Customer.SingleOrDefault(m => m.ID == id);

            if (customerUpDb == null)
                throw new HttpResponseException(HttpStatusCode.NotFound);

            _context.Customer.Remove(customerUpDb);
            _context.SaveChanges();
        }
    }
}
