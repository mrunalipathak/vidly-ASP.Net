﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data.Entity;
using Vidly.Models;
using Vidly.Dtos;
using AutoMapper;

namespace Vidly.Controllers.Api
{
    public class MoviesController : ApiController
    {
        private ApplicationDbContext _context;

        public MoviesController()
        {
            _context = new ApplicationDbContext();
        }

        //GET /api/movies
        public IEnumerable<MoviesDtos> GetMovies()
        {
            return _context.Movies.Include(c => c.Genres).ToList().Select(Mapper.Map<Movies, MoviesDtos>);
        }

        //GET /api/movies/1
        public IHttpActionResult GetMovies(int id)
        {
            var movies = _context.Movies.SingleOrDefault(c=>c.ID == id);

            if (movies == null)
                return NotFound();

            return Ok(Mapper.Map<Movies, MoviesDtos>(movies));
        }

        //POST /api/movies
        [HttpPost]
        [Authorize(Roles = RoleName.CanManageMovies)]
        public IHttpActionResult CreateMovies(MoviesDtos movieDtos)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            var movies = Mapper.Map<MoviesDtos, Movies>(movieDtos);
            _context.Movies.Add(movies);
            _context.SaveChanges();

            movieDtos.ID = movies.ID;

            return Created(new Uri(Request.RequestUri + "/" + movies.ID), movieDtos);
        }

        //PUT /api/movies/1
        [HttpPut]
        [Authorize(Roles = RoleName.CanManageMovies)]
        public void UpdateMovies(int id, MoviesDtos moviesDtos)
        {
            if (!ModelState.IsValid)
                throw new HttpResponseException(HttpStatusCode.BadRequest);

            var moviesUpDb = _context.Movies.SingleOrDefault(m => m.ID == id);

            if (moviesUpDb == null)
                throw new HttpResponseException(HttpStatusCode.NotFound);

            Mapper.Map(moviesDtos, moviesUpDb);

            _context.SaveChanges();
        }

        //DELETE api/movies/id
        [HttpDelete]
        [Authorize(Roles = RoleName.CanManageMovies)]
        public void DeleteMovies(int id)
        {
            var moviesUpDb = _context.Movies.SingleOrDefault(m => m.ID == id);

            if (moviesUpDb == null)
                throw new HttpResponseException(HttpStatusCode.NotFound);

            _context.Movies.Remove(moviesUpDb);
            _context.SaveChanges();
        }

    }
}
