﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Vidly.Dtos;
using Vidly.Models;

namespace Vidly.Controllers.Api
{
    public class MoviesRentalController : ApiController
    {
        ApplicationDbContext _applicationDbContext = null;

        public MoviesRentalController()
        {
            _applicationDbContext = new ApplicationDbContext();
        }

        //POST /api/moviesrental
        [HttpPost]
        public IHttpActionResult CreateNewRentals(NewRentalDtos newRentalDtos)
        {
            //if (newRentalDtos.MoviesIDList.Count == 0)
            //    return BadRequest("No MovieIds have been given.");

            var customer = _applicationDbContext.Customer.SingleOrDefault(x => x.ID == newRentalDtos.CutomerID);

            //if (customer == null)
            //    return BadRequest("Customer is not valid.");


            var movies = _applicationDbContext.Movies.Where(m => newRentalDtos.MoviesIDList.Contains(m.ID)).ToList();

            //if (movies.Count != newRentalDtos.MoviesIDList.Count)
            //    return BadRequest("One or more movies Ids are Invalid");

            foreach (var newRental in movies)
            {
                if (newRental.NumberInAvailable == 0)
                    return BadRequest("Movie not available");

                newRental.NumberInAvailable--;

                var rental = new Rental
                {
                    Customer = customer,
                    Movies = newRental,
                    DateRented = DateTime.Now
                };
                _applicationDbContext.Rental.Add(rental);
            }

            _applicationDbContext.SaveChanges();

            return Ok();
        }

    }
}
