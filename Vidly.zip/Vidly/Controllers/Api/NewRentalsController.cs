﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Vidly.Dtos;
using Vidly.Models;

namespace Vidly.Controllers.Api
{
    public class NewRentalsController : ApiController
    {
        ApplicationDbContext _applicationDbContext = null;

        public NewRentalsController()
        {
            _applicationDbContext = new ApplicationDbContext();
        }

        //POST /api/newRentals
        //public IHttpActionResult CreateNewRentals(NewRentalDtos newRentalDtos)
        //[HttpPost]
        //public IHttpActionResult CreateNewRentals(string customerID, string movieID)
        //POST /api/newRentals
        public IHttpActionResult CreateNewRentals([FromBody]NewRentalDtos newRentalDtos)
        {
            //if (newRentalDtos.MoviesIDList.Count == 0)
            //    return BadRequest("No MovieIds have been given.");

            var customer = _applicationDbContext.Customer.Single(x => x.ID == newRentalDtos.customerId);
            // var customer = _applicationDbContext.Customer.Single(x => x.ID == Convert.ToInt16(customerID));

            //if (customer == null)
            //    return BadRequest("Customer is not valid.");


            var movies = _applicationDbContext.Movies.Where(m => newRentalDtos.movieIds.Contains(m.ID)).ToList();
            //var movies = _applicationDbContext.Movies.Where(m => m.ID == Convert.ToInt16(movieID)).ToList();

            //if (movies.Count != newRentalDtos.MoviesIDList.Count)
            //    return BadRequest("One or more movies Ids are Invalid");

            foreach (var newRental in movies)
            {
                if (newRental.NumberInAvailable == 0)
                    return BadRequest("Movie not available");

                newRental.NumberInAvailable--;

                var rental = new Rental
                {
                    Customer = customer,
                    Movies = newRental,
                    DateRented = DateTime.Now
                };
                _applicationDbContext.Rental.Add(rental);
            }

            _applicationDbContext.SaveChanges();

            return Ok();
        }

    }
}
