﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vidly.Models;
using Vidly.ViewModel;
using System.Data.Entity;

namespace Vidly.Controllers
{
    public class MoviesController : Controller
    {
        private ApplicationDbContext _context;

        public MoviesController()
        {
            _context = new ApplicationDbContext();
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }
        // GET: Movies/Random
        public ActionResult Index()
        {
            if (User.IsInRole(RoleName.CanManageMovies)) 
                return View("List");

            return View("ReadOnlyList");
        }

        public ActionResult Details(int id)
        {
            var GeneresDetails = _context.Movies.Include(c => c.Genres).SingleOrDefault(c => c.ID == id);

            if (GeneresDetails == null)
                return HttpNotFound();

            return View(GeneresDetails);
        }

        [Authorize(Roles = RoleName.CanManageMovies)]
        public ActionResult New()
        {
            var genres = _context.Genres.ToList();
            var viewModel = new GenresFormViewModel()
            {
                GenresList = genres
            };
            return View("MovieForm", viewModel);
        }
        [Authorize(Roles = RoleName.CanManageMovies)]
        public ActionResult Edit(int Id)
        {
            var movies = _context.Movies.SingleOrDefault(c => c.ID == Id);

            if (movies == null)
                return HttpNotFound();

            var viewModel = new GenresFormViewModel()
            {
               
                GenresList = _context.Genres.ToList()
            };

            return View("MovieForm", viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Save(Movies movies)
        {
            if(!ModelState.IsValid)
            {
                var viewModel = new GenresFormViewModel(movies)
                {
                    GenresList = _context.Genres.ToList()
                };
                return View ("MovieForm",viewModel);
            }

            if (movies.ID == 0)
            {
                if (movies.Genres == null)
                {
                    movies.Genres = _context.Genres.SingleOrDefault(x => x.ID == movies.GenresID);
                }
                movies.DateAdded = DateTime.Now;
                _context.Movies.Add(movies);
            }
               
            else
            {
                var updateMovies = _context.Movies.Single(c => c.ID == movies.ID);

                updateMovies.Name = movies.Name;
                updateMovies.NumberInStock = movies.NumberInStock;
                updateMovies.GenresID = movies.GenresID;
                updateMovies.ReleasedDate = movies.ReleasedDate;
                updateMovies.Genres = _context.Genres.Single(x => x.ID == updateMovies.GenresID);
            }
            _context.SaveChanges();

            return RedirectToAction("Index", "Movies");
        }

        //private IEnumerable<Movies> GetMovies()
        //{
        //    return new List<Movies>
        //    {
        //       new Movies{Name = "SHREK !"},
        //        new Movies{Name = "Jelly !"}
        //    };
        //}
        //public ActionResult Random()
        //{
        //    var movie = new List<Movies>
        //    { 
        //        new Movies{Name = "SHREK !"},
        //        new Movies{Name = "Jelly !"}
        //    };
          
        //    var customers = new List<Customers>
        //    {
        //        new Customers{ID = 1, Name = "Customer 1"},
        //        new Customers{ID = 2, Name = "Customer 2"}
        //    };

        //    var viewModel = new RandomMoviesViewModel
        //    {
        //        Movies = movie,
        //        CustomerList = customers
        //    };
            
        //    return View(viewModel);
        //   // return Content("Hello");
        //    //return RedirectToAction("Index", "Home", new { page = 1, sortyby = "name" });
        //}

        //public ActionResult Edit(int id)
        //{
        //    return Content("id " +id);
        //}

        ////movies
        //public ActionResult Index(int? pageIndex, string sortBy)
        //{
        //    if (!pageIndex.HasValue)
        //        pageIndex = 1;

        //    if (string.IsNullOrWhiteSpace(sortBy))
        //        sortBy = "Name";

        //    return Content(string.Format("PageIndex={0} and sortyby={1}", pageIndex, sortBy));
        //}

        //[Route("movies/MoviesRelasedDate/{year}/{month:regex(\\d{4}):range(1,12)}")]
        //public ActionResult MoviesRelasedDate(int year, int month)
        //{
        //    return Content(year + "/" + month);
        //}
    }
}