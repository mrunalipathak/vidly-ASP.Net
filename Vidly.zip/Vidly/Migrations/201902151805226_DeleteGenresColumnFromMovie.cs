namespace Vidly.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DeleteGenresColumnFromMovie : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Movies", "Genres_ID", "dbo.Genres");
            DropIndex("dbo.Movies", new[] { "Genres_ID" });
            DropColumn("dbo.Movies", "GenresID");
            RenameColumn(table: "dbo.Movies", name: "Genres_ID", newName: "GenresID");
            AlterColumn("dbo.Movies", "GenresID", c => c.Int(nullable: false));
            AlterColumn("dbo.Movies", "GenresID", c => c.Int(nullable: false));
            CreateIndex("dbo.Movies", "GenresID");
            AddForeignKey("dbo.Movies", "GenresID", "dbo.Genres", "ID", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Movies", "GenresID", "dbo.Genres");
            DropIndex("dbo.Movies", new[] { "GenresID" });
            AlterColumn("dbo.Movies", "GenresID", c => c.Int());
            AlterColumn("dbo.Movies", "GenresID", c => c.Byte(nullable: false));
            RenameColumn(table: "dbo.Movies", name: "GenresID", newName: "Genres_ID");
            AddColumn("dbo.Movies", "GenresID", c => c.Byte(nullable: false));
            CreateIndex("dbo.Movies", "Genres_ID");
            AddForeignKey("dbo.Movies", "Genres_ID", "dbo.Genres", "ID");
        }
    }
}
