namespace Vidly.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddGenres : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Genres",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 255),
                    })
                .PrimaryKey(t => t.ID);
            
            AddColumn("dbo.Movies", "Genres_ID", c => c.Int());
            CreateIndex("dbo.Movies", "Genres_ID");
            AddForeignKey("dbo.Movies", "Genres_ID", "dbo.Genres", "ID");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Movies", "Genres_ID", "dbo.Genres");
            DropIndex("dbo.Movies", new[] { "Genres_ID" });
            DropColumn("dbo.Movies", "Genres_ID");
            DropTable("dbo.Genres");
        }
    }
}
