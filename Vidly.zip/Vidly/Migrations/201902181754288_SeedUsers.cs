namespace Vidly.Migrations
{
    using System;
    using System.Data.Entity.Migrations;

    public partial class SeedUsers : DbMigration
    {
        public override void Up()
        {
            Sql(@"
INSERT INTO [dbo].[AspNetUsers] ([Id], [Email], [EmailConfirmed], [PasswordHash], [SecurityStamp], [PhoneNumber], [PhoneNumberConfirmed], [TwoFactorEnabled], [LockoutEndDateUtc], [LockoutEnabled], [AccessFailedCount], [UserName]) VALUES (N'4bf22922-3b11-41a5-839d-d0f00eb082f1', N'admin@vidly.com', 0, N'AMsyWkG4N2MZA64wi2vxErij21daB+tVNjEg7y945h3/+iC1Ggfp8CXKi1wJ/y4JqA==', N'4a949730-2be9-4e39-943e-53af93cda920', NULL, 0, 0, NULL, 1, 0, N'admin@vidly.com')
INSERT INTO [dbo].[AspNetUsers] ([Id], [Email], [EmailConfirmed], [PasswordHash], [SecurityStamp], [PhoneNumber], [PhoneNumberConfirmed], [TwoFactorEnabled], [LockoutEndDateUtc], [LockoutEnabled], [AccessFailedCount], [UserName]) VALUES (N'c1dbc0c1-979c-4d2e-a8b9-91e362458d2a', N'guest@vidly.com', 0, N'ALE26PZcf5MsKJziMrL91M6f0XuhPmvLsClnY9J+4SFmBGt/ndsTxwaykvRiIVPsIQ==', N'325f1267-dbdd-4805-8483-9fa4f3c5f2e8', NULL, 0, 0, NULL, 1, 0, N'guest@vidly.com')

INSERT INTO [dbo].[AspNetRoles] ([Id], [Name]) VALUES (N'1352d0fd-07fe-4d44-b14a-5bd00a46012b', N'CanManageMovies')

INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId]) VALUES (N'4bf22922-3b11-41a5-839d-d0f00eb082f1', N'1352d0fd-07fe-4d44-b14a-5bd00a46012b')

");
        }

        public override void Down()
        {
        }
    }
}
