namespace Vidly.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DeleteColumnExtraMembershipTypeID : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Customers", "MembershipType_ID", "dbo.MembershipTypes");
            DropIndex("dbo.Customers", new[] { "MembershipType_ID" });
            DropColumn("dbo.Customers", "MembershipTypeID");
            RenameColumn(table: "dbo.Customers", name: "MembershipType_ID", newName: "MembershipTypeID");
            AlterColumn("dbo.Customers", "MembershipTypeID", c => c.Int(nullable: false));
            AlterColumn("dbo.Customers", "MembershipTypeID", c => c.Int(nullable: false));
            CreateIndex("dbo.Customers", "MembershipTypeID");
            AddForeignKey("dbo.Customers", "MembershipTypeID", "dbo.MembershipTypes", "ID", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Customers", "MembershipTypeID", "dbo.MembershipTypes");
            DropIndex("dbo.Customers", new[] { "MembershipTypeID" });
            AlterColumn("dbo.Customers", "MembershipTypeID", c => c.Int());
            AlterColumn("dbo.Customers", "MembershipTypeID", c => c.Byte(nullable: false));
            RenameColumn(table: "dbo.Customers", name: "MembershipTypeID", newName: "MembershipType_ID");
            AddColumn("dbo.Customers", "MembershipTypeID", c => c.Byte(nullable: false));
            CreateIndex("dbo.Customers", "MembershipType_ID");
            AddForeignKey("dbo.Customers", "MembershipType_ID", "dbo.MembershipTypes", "ID");
        }
    }
}
