﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Vidly.Models;

namespace Vidly.ViewModel
{
    public class CustomerFormViewModel
    {

        public IEnumerable<MembershipType> MembershipType { get; set; }

        public int? ID { get; set; }

        [Required]
        [StringLength(255)]
        public string Name { get; set; }

        public bool IsSubscriberToNewsLetter { get; set; }

        public int? MembershipTypeID { get; set; }

        [Min18YearsIfAMember]
        public DateTime? BirthDate { get; set; }

        //public Customers Customer { get; set; }

        public CustomerFormViewModel()
        {
            ID = 0;
        }
        public CustomerFormViewModel(Customers customer)
        {
            ID = customer.ID;
            Name = customer.Name;
            IsSubscriberToNewsLetter = customer.IsSubscriberToNewsLetter;
            MembershipTypeID = customer.MembershipTypeID;
            BirthDate = customer.BirthDate;
        }

    }
}