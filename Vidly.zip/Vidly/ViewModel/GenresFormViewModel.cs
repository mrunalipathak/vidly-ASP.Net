﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Vidly.Models;

namespace Vidly.ViewModel
{
    public class GenresFormViewModel
    {
        public IEnumerable<Genres> GenresList { get; set; }

        public int? ID { get; set; }

        [Required]
        [StringLength(255)]
        public string Name { get; set; }

        [Display(Name = "Released Date")]
        [Required]
        public DateTime? ReleasedDate { get; set; }

        [Required]
        public DateTime? DateAdded { get; set; }

        [Display(Name = "Number in stock")]
        [Range(1, 20)]
        [Required]
        public int? NumberInStock { get; set; }

        [Display(Name = "Genres")]
        [Required]
        public int? GenresID { get; set; }

        public string  Title 
        {
            get
            {
                return ID != 0 ? "Edit Movie" : "New Movie";
            }
        }

        public GenresFormViewModel()
        {
            ID = 0;
        }

        public GenresFormViewModel(Movies movie)
        {
            ID = movie.ID;
            Name = movie.Name;
            ReleasedDate = movie.ReleasedDate;
            DateAdded = movie.DateAdded;
            GenresID = movie.GenresID;
        }
    }
}