﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Vidly.Models;
using Vidly.Dtos;

namespace Vidly.App_Start
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            Mapper.CreateMap<Customers, CustomerDtos>();
            Mapper.CreateMap<Movies, MoviesDtos>();
            Mapper.CreateMap<MembershipType, MembershipTypeDtos>();
            Mapper.CreateMap<Genres, GenerDtos>();

            Mapper.CreateMap<MembershipTypeDtos, MembershipType>();
            Mapper.CreateMap<CustomerDtos, Customers>()
                .ForMember(c=>c.ID, opt=>opt.Ignore());
            Mapper.CreateMap<MoviesDtos, Movies>()
                .ForMember(c => c.ID, opt => opt.Ignore());
        }
    }
}